export class Producto {
    id: string;
    descripcion: string;

    constructor(id: string, descripcion: string) {
        this.id = id;
        this.descripcion = descripcion;
    }
}
